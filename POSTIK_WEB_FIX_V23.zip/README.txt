POSTIK WEB FIX V23
1) Upload this ZIP to the root of nizzarr-aj/postik.
2) Run Actions -> Unpack POSTIK Web Fix.
3) The workflow replaces app.js, style.css and index.html.
4) Do NOT replace config.js.
5) V23 adds stronger Android WebView RTL horizontal-scroll and modal fixes.
