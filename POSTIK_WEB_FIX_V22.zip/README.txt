POSTIK Web Fix V22

Replace app.js, style.css and index.html in the POSTIK GitHub Pages repo.
Fixes: Android WebView RTL horizontal scroll, scrollIntoView issue, mobile overflow, cache-busting to v22.
Do not replace config.js.
